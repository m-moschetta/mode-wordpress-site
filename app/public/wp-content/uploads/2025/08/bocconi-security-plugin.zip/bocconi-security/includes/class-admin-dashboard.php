<?php
/**
 * Bocconi Security Admin Dashboard
 * 
 * Gestisce l'interfaccia di amministrazione del plugin
 * 
 * @package BocconiSecurity
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class BocconiSecurityAdminDashboard {
    
    private $config;
    private $implementation;
    
    public function __construct() {
        $this->config = BocconiSecurityConfig::getInstance();
        $this->implementation = new BocconiSecurityImplementation();
        
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('wp_ajax_bocconi_security_scan', array($this, 'ajax_security_scan'));
        add_action('wp_ajax_bocconi_security_test', array($this, 'ajax_security_test'));
    }
    
    public function add_admin_menu() {
        add_menu_page(
            'Bocconi Security',
            'Bocconi Security',
            'manage_options',
            'bocconi-security',
            array($this, 'admin_page'),
            'dashicons-shield-alt',
            30
        );
        
        add_submenu_page(
            'bocconi-security',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'bocconi-security',
            array($this, 'admin_page')
        );
        
        add_submenu_page(
            'bocconi-security',
            'Configurazione',
            'Configurazione',
            'manage_options',
            'bocconi-security-config',
            array($this, 'config_page')
        );
        
        add_submenu_page(
            'bocconi-security',
            'Log di Sicurezza',
            'Log di Sicurezza',
            'manage_options',
            'bocconi-security-logs',
            array($this, 'logs_page')
        );
        
        add_submenu_page(
            'bocconi-security',
            'Report OWASP',
            'Report OWASP',
            'manage_options',
            'bocconi-security-report',
            array($this, 'report_page')
        );
    }
    
    public function register_settings() {
        register_setting('bocconi_security_options', 'bocconi_security_options', array(
            'sanitize_callback' => array($this, 'sanitize_options')
        ));
    }
    
    public function sanitize_options($options) {
        $sanitized = array();
        
        foreach ($options as $key => $value) {
            $sanitized[$key] = $this->config->validate_option($key, $value);
        }
        
        return $sanitized;
    }
    
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'bocconi-security') === false) {
            return;
        }
        
        wp_enqueue_style('bocconi-security-admin', plugin_dir_url(dirname(__FILE__)) . 'assets/admin.css', array(), '1.0.0');
        wp_enqueue_script('bocconi-security-admin', plugin_dir_url(dirname(__FILE__)) . 'assets/admin.js', array('jquery'), '1.0.0', true);
        
        wp_localize_script('bocconi-security-admin', 'bocconiSecurity', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('bocconi_security_nonce'),
            'strings' => array(
                'scanning' => 'Scansione in corso...',
                'scan_complete' => 'Scansione completata',
                'scan_error' => 'Errore durante la scansione'
            )
        ));
    }
    
    public function admin_page() {
        $security_level = $this->config->get_security_level();
        $recent_threats = $this->get_recent_threats();
        $system_status = $this->get_system_status();
        
        ?>
        <div class="wrap">
            <h1><span class="dashicons dashicons-shield-alt"></span> Bocconi Security Dashboard</h1>
            
            <div class="bocconi-security-dashboard">
                <!-- Security Level Card -->
                <div class="security-card">
                    <h2>Livello di Sicurezza</h2>
                    <div class="security-meter">
                        <div class="meter-bar">
                            <div class="meter-fill" style="width: <?php echo $security_level; ?>%;"></div>
                        </div>
                        <span class="meter-text"><?php echo $security_level; ?>%</span>
                    </div>
                    <p class="security-status <?php echo $this->get_security_status_class($security_level); ?>">
                        <?php echo $this->get_security_status_text($security_level); ?>
                    </p>
                </div>
                
                <!-- Quick Actions -->
                <div class="security-card">
                    <h2>Azioni Rapide</h2>
                    <div class="quick-actions">
                        <button class="button button-primary" id="security-scan">Scansione Sicurezza</button>
                        <button class="button" id="update-config">Aggiorna Configurazione</button>
                        <button class="button" id="export-logs">Esporta Log</button>
                    </div>
                </div>
                
                <!-- System Status -->
                <div class="security-card">
                    <h2>Stato del Sistema</h2>
                    <table class="widefat">
                        <tbody>
                            <?php foreach ($system_status as $check => $status): ?>
                            <tr>
                                <td><?php echo esc_html($check); ?></td>
                                <td>
                                    <span class="status-indicator <?php echo $status['status']; ?>">
                                        <?php echo $status['message']; ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Recent Threats -->
                <div class="security-card">
                    <h2>Minacce Recenti</h2>
                    <?php if (empty($recent_threats)): ?>
                        <p>Nessuna minaccia rilevata nelle ultime 24 ore.</p>
                    <?php else: ?>
                        <table class="widefat">
                            <thead>
                                <tr>
                                    <th>Tipo</th>
                                    <th>IP</th>
                                    <th>Data/Ora</th>
                                    <th>Azione</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_threats as $threat): ?>
                                <tr>
                                    <td><?php echo esc_html($threat['type']); ?></td>
                                    <td><?php echo esc_html($threat['ip']); ?></td>
                                    <td><?php echo esc_html($threat['datetime']); ?></td>
                                    <td><?php echo esc_html($threat['action']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <style>
        .bocconi-security-dashboard {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .security-card {
            background: #fff;
            border: 1px solid #ccd0d4;
            border-radius: 4px;
            padding: 20px;
            box-shadow: 0 1px 1px rgba(0,0,0,.04);
        }
        
        .security-card h2 {
            margin-top: 0;
            margin-bottom: 15px;
            font-size: 18px;
        }
        
        .security-meter {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 10px;
        }
        
        .meter-bar {
            flex: 1;
            height: 20px;
            background: #f0f0f1;
            border-radius: 10px;
            overflow: hidden;
        }
        
        .meter-fill {
            height: 100%;
            background: linear-gradient(90deg, #dc3232 0%, #ffb900 50%, #46b450 100%);
            transition: width 0.3s ease;
        }
        
        .meter-text {
            font-weight: bold;
            font-size: 16px;
        }
        
        .security-status {
            font-weight: bold;
            margin: 0;
        }
        
        .security-status.low { color: #dc3232; }
        .security-status.medium { color: #ffb900; }
        .security-status.high { color: #46b450; }
        
        .quick-actions {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .status-indicator {
            padding: 4px 8px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: bold;
        }
        
        .status-indicator.pass {
            background: #d4edda;
            color: #155724;
        }
        
        .status-indicator.fail {
            background: #f8d7da;
            color: #721c24;
        }
        
        .status-indicator.warning {
            background: #fff3cd;
            color: #856404;
        }
        </style>
        <?php
    }
    
    public function config_page() {
        if (isset($_POST['submit'])) {
            check_admin_referer('bocconi_security_config');
            
            $options = $_POST['bocconi_security'] ?? array();
            $this->config->update_options($options);
            
            echo '<div class="notice notice-success"><p>Configurazione salvata con successo!</p></div>';
        }
        
        $current_options = $this->config->get_all_options();
        
        ?>
        <div class="wrap">
            <h1>Configurazione Bocconi Security</h1>
            
            <form method="post" action="">
                <?php wp_nonce_field('bocconi_security_config'); ?>
                
                <div class="config-sections">
                    <!-- Architettura -->
                    <div class="config-section">
                        <h2>V1 - Sicurezza dell'Architettura</h2>
                        <table class="form-table">
                            <tr>
                                <th scope="row">Nascondi Versione WordPress</th>
                                <td>
                                    <input type="checkbox" name="bocconi_security[hide_wp_version]" value="1" <?php checked($current_options['hide_wp_version']); ?> />
                                    <p class="description">Rimuove la versione di WordPress dall'HTML</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Disabilita XML-RPC</th>
                                <td>
                                    <input type="checkbox" name="bocconi_security[disable_xmlrpc]" value="1" <?php checked($current_options['disable_xmlrpc']); ?> />
                                    <p class="description">Disabilita l'endpoint XML-RPC per prevenire attacchi</p>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <!-- Autenticazione -->
                    <div class="config-section">
                        <h2>V2 - Autenticazione</h2>
                        <table class="form-table">
                            <tr>
                                <th scope="row">Tentativi di Login Massimi</th>
                                <td>
                                    <input type="number" name="bocconi_security[max_login_attempts]" value="<?php echo esc_attr($current_options['max_login_attempts']); ?>" min="1" max="20" />
                                    <p class="description">Numero massimo di tentativi di login falliti prima del blocco</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Durata Blocco (secondi)</th>
                                <td>
                                    <input type="number" name="bocconi_security[lockout_duration]" value="<?php echo esc_attr($current_options['lockout_duration']); ?>" min="300" max="86400" />
                                    <p class="description">Durata del blocco IP in secondi (300-86400)</p>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <!-- Gestione Sessioni -->
                    <div class="config-section">
                        <h2>V3 - Gestione Sessioni</h2>
                        <table class="form-table">
                            <tr>
                                <th scope="row">Timeout Sessione (secondi)</th>
                                <td>
                                    <input type="number" name="bocconi_security[session_timeout]" value="<?php echo esc_attr($current_options['session_timeout']); ?>" min="300" max="7200" />
                                    <p class="description">Timeout automatico delle sessioni in secondi</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Cookie Sicuri</th>
                                <td>
                                    <input type="checkbox" name="bocconi_security[secure_cookies]" value="1" <?php checked($current_options['secure_cookies']); ?> />
                                    <p class="description">Imposta i cookie come sicuri e HttpOnly</p>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <!-- Comunicazioni -->
                    <div class="config-section">
                        <h2>V9 - Sicurezza delle Comunicazioni</h2>
                        <table class="form-table">
                            <tr>
                                <th scope="row">Forza HTTPS</th>
                                <td>
                                    <input type="checkbox" name="bocconi_security[force_https]" value="1" <?php checked($current_options['force_https']); ?> />
                                    <p class="description">Forza l'uso di HTTPS per tutto il sito</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Header di Sicurezza</th>
                                <td>
                                    <input type="checkbox" name="bocconi_security[security_headers]" value="1" <?php checked($current_options['security_headers']); ?> />
                                    <p class="description">Aggiunge header di sicurezza HTTP</p>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <!-- Monitoraggio -->
                    <div class="config-section">
                        <h2>Monitoraggio e Alert</h2>
                        <table class="form-table">
                            <tr>
                                <th scope="row">Email per Alert</th>
                                <td>
                                    <input type="email" name="bocconi_security[alert_email]" value="<?php echo esc_attr($current_options['alert_email']); ?>" class="regular-text" />
                                    <p class="description">Email per ricevere gli alert di sicurezza</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Abilita Logging</th>
                                <td>
                                    <input type="checkbox" name="bocconi_security[enable_logging]" value="1" <?php checked($current_options['enable_logging']); ?> />
                                    <p class="description">Abilita il logging degli eventi di sicurezza</p>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
                
                <?php submit_button('Salva Configurazione'); ?>
            </form>
        </div>
        
        <style>
        .config-sections {
            margin-top: 20px;
        }
        
        .config-section {
            background: #fff;
            border: 1px solid #ccd0d4;
            border-radius: 4px;
            margin-bottom: 20px;
            padding: 20px;
        }
        
        .config-section h2 {
            margin-top: 0;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        </style>
        <?php
    }
    
    public function logs_page() {
        $logs = $this->get_security_logs();
        
        ?>
        <div class="wrap">
            <h1>Log di Sicurezza</h1>
            
            <div class="log-filters">
                <form method="get">
                    <input type="hidden" name="page" value="bocconi-security-logs" />
                    <select name="log_level">
                        <option value="">Tutti i livelli</option>
                        <option value="error" <?php selected($_GET['log_level'] ?? '', 'error'); ?>>Errori</option>
                        <option value="warning" <?php selected($_GET['log_level'] ?? '', 'warning'); ?>>Avvisi</option>
                        <option value="info" <?php selected($_GET['log_level'] ?? '', 'info'); ?>>Info</option>
                    </select>
                    <input type="date" name="date_from" value="<?php echo esc_attr($_GET['date_from'] ?? ''); ?>" />
                    <input type="date" name="date_to" value="<?php echo esc_attr($_GET['date_to'] ?? ''); ?>" />
                    <input type="submit" class="button" value="Filtra" />
                </form>
            </div>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Data/Ora</th>
                        <th>Livello</th>
                        <th>Evento</th>
                        <th>IP</th>
                        <th>Dettagli</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($logs)): ?>
                        <tr>
                            <td colspan="5">Nessun log trovato.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?php echo esc_html($log['datetime']); ?></td>
                            <td><span class="log-level <?php echo esc_attr($log['level']); ?>"><?php echo esc_html(strtoupper($log['level'])); ?></span></td>
                            <td><?php echo esc_html($log['event']); ?></td>
                            <td><?php echo esc_html($log['ip']); ?></td>
                            <td><?php echo esc_html($log['details']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <style>
        .log-filters {
            background: #fff;
            border: 1px solid #ccd0d4;
            border-radius: 4px;
            padding: 15px;
            margin: 20px 0;
        }
        
        .log-filters form {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        
        .log-level {
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 11px;
            font-weight: bold;
        }
        
        .log-level.error { background: #f8d7da; color: #721c24; }
        .log-level.warning { background: #fff3cd; color: #856404; }
        .log-level.info { background: #d1ecf1; color: #0c5460; }
        </style>
        <?php
    }
    
    public function report_page() {
        // Include the OWASP checker
        include_once(ABSPATH . 'owasp-security-checker.php');
        
        ?>
        <div class="wrap">
            <h1>Report OWASP ASVS</h1>
            
            <div class="report-actions">
                <button class="button button-primary" id="generate-report">Genera Nuovo Report</button>
                <button class="button" id="export-report">Esporta Report</button>
            </div>
            
            <div id="owasp-report-container">
                <!-- Il report verrà caricato qui via AJAX -->
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            $('#generate-report').on('click', function() {
                var button = $(this);
                button.prop('disabled', true).text('Generazione in corso...');
                
                $.post(ajaxurl, {
                    action: 'bocconi_security_report',
                    nonce: '<?php echo wp_create_nonce('bocconi_security_nonce'); ?>'
                }, function(response) {
                    if (response.success) {
                        $('#owasp-report-container').html(response.data);
                    } else {
                        alert('Errore nella generazione del report');
                    }
                }).always(function() {
                    button.prop('disabled', false).text('Genera Nuovo Report');
                });
            });
            
            // Genera automaticamente il report al caricamento della pagina
            $('#generate-report').trigger('click');
        });
        </script>
        <?php
    }
    
    // AJAX Handlers
    public function ajax_security_scan() {
        check_ajax_referer('bocconi_security_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Accesso negato');
        }
        
        $scan_results = $this->implementation->run_security_scan();
        
        wp_send_json_success($scan_results);
    }
    
    public function ajax_security_test() {
        check_ajax_referer('bocconi_security_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Accesso negato');
        }
        
        $test_results = $this->implementation->run_security_tests();
        
        wp_send_json_success($test_results);
    }
    
    // Helper Methods
    private function get_security_status_class($level) {
        if ($level >= 80) return 'high';
        if ($level >= 60) return 'medium';
        return 'low';
    }
    
    private function get_security_status_text($level) {
        if ($level >= 80) return 'Sicurezza Elevata';
        if ($level >= 60) return 'Sicurezza Media';
        return 'Sicurezza Bassa - Azione Richiesta';
    }
    
    private function get_recent_threats() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'bocconi_security_logs';
        
        $threats = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table_name} 
             WHERE level IN ('warning', 'error') 
             AND datetime >= %s 
             ORDER BY datetime DESC 
             LIMIT 10",
            date('Y-m-d H:i:s', strtotime('-24 hours'))
        ), ARRAY_A);
        
        return $threats ?: array();
    }
    
    private function get_system_status() {
        $status = array();
        
        // WordPress Version
        $wp_version = get_bloginfo('version');
        $latest_version = $this->get_latest_wp_version();
        $status['WordPress Version'] = array(
            'status' => version_compare($wp_version, $latest_version, '>=') ? 'pass' : 'warning',
            'message' => "Versione {$wp_version}" . (version_compare($wp_version, $latest_version, '<') ? ' (aggiornamento disponibile)' : '')
        );
        
        // HTTPS
        $status['HTTPS'] = array(
            'status' => is_ssl() ? 'pass' : 'fail',
            'message' => is_ssl() ? 'Attivo' : 'Non attivo'
        );
        
        // Debug Mode
        $status['Debug Mode'] = array(
            'status' => WP_DEBUG ? 'warning' : 'pass',
            'message' => WP_DEBUG ? 'Attivo (disabilitare in produzione)' : 'Disattivato'
        );
        
        // File Permissions
        $wp_config_perms = substr(sprintf('%o', fileperms(ABSPATH . 'wp-config.php')), -4);
        $status['Permessi wp-config.php'] = array(
            'status' => ($wp_config_perms === '0644' || $wp_config_perms === '0600') ? 'pass' : 'warning',
            'message' => $wp_config_perms
        );
        
        return $status;
    }
    
    private function get_latest_wp_version() {
        $version_check = wp_remote_get('https://api.wordpress.org/core/version-check/1.7/');
        
        if (is_wp_error($version_check)) {
            return get_bloginfo('version');
        }
        
        $version_data = json_decode(wp_remote_retrieve_body($version_check), true);
        
        return $version_data['offers'][0]['version'] ?? get_bloginfo('version');
    }
    
    private function get_security_logs($filters = array()) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'bocconi_security_logs';
        
        $where_clauses = array('1=1');
        $where_values = array();
        
        if (!empty($filters['log_level'])) {
            $where_clauses[] = 'level = %s';
            $where_values[] = $filters['log_level'];
        }
        
        if (!empty($filters['date_from'])) {
            $where_clauses[] = 'DATE(datetime) >= %s';
            $where_values[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $where_clauses[] = 'DATE(datetime) <= %s';
            $where_values[] = $filters['date_to'];
        }
        
        $where_clause = implode(' AND ', $where_clauses);
        
        $query = "SELECT * FROM {$table_name} WHERE {$where_clause} ORDER BY datetime DESC LIMIT 100";
        
        if (!empty($where_values)) {
            $query = $wpdb->prepare($query, $where_values);
        }
        
        $logs = $wpdb->get_results($query, ARRAY_A);
        
        return $logs ?: array();
    }
}

// Initialize admin dashboard
if (is_admin()) {
    new BocconiSecurityAdminDashboard();
}